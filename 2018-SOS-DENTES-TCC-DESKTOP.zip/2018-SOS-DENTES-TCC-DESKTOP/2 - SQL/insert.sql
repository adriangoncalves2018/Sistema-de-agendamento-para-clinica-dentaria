--Insert funcion�rio 
INSERT INTO Funcionario VALUES ('ADRIAN GON�ALVES','03/03/2001','547161979','50321748824','MASCULINO','adrianamazonas2015@gmail.com',
'123456789','11982138584','Rua Alfa','257', 'Vila Gi�ia', 'apt 322B apto 3B', 'Itapevi', '06680103', 'Dentista', 'SP',1)
INSERT INTO Funcionario VALUES ('JOAO','03/03/2001','547161979','50321748824','MASCULINO','adrianamazonas2015@gmail.com',
'123456789','11982138584','Rua Alfa','257', 'Vila Gi�ia', 'apt 322B apto 3B', 'Itapevi', '06680103', 'Dentista', 'SP',1)
INSERT INTO Funcionario VALUES ('JOS�','03/03/2001','547161979','50321748824','MASCULINO','adrianamazonas2015@gmail.com',
'123456789','11982138584','Rua Alfa','257', 'Vila Gi�ia', 'apt 322B apto 3B', 'Itapevi', '06680103', 'Dentista', 'SP',1)


--Insert Paciente
INSERT INTO Paciente VALUES('adrian','03/03/2001','adrianamazonas2015@gmail.com','11982138584','547161979','1141449520','Masculino','rua alfa','50321748824','vila gi�ia','','257','06657230','sp','itapevi','',1)
INSERT INTO Paciente VALUES('LUCAS','03/03/2001','','11982138584','547161979','1141449520','Masculino','rua alfa','50321748824','vila gi�ia','','257','06657230','sp','itapevi','',1)
INSERT INTO Paciente VALUES('PEDRO','03/03/2001','','11982138584','547161979','1141449520','Masculino','rua alfa','50321748824','vila gi�ia','','257','06657230','sp','itapevi','',1)
INSERT INTO Paciente VALUES('MARCELO','03/03/2001','','11982138584','547161979','1141449520','Masculino','rua alfa','50321748824','vila gi�ia','','257','06657230','sp','itapevi','',1)
INSERT INTO Paciente VALUES('MARIA','09/09/1998','','11982138584','547161979','1141449520','Feminino','rua alfa','50321748824','vila gi�ia','','257','06657230','sp','itapevi','',1)
